package practice;

public class DepositAccount extends BankAccount {

}
